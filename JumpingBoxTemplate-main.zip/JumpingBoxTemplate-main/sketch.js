var canvas;
var music;

function preload(){
    music = loadSound("music.mp3");
}


function setup(){
    box1 = createSprite(110,580,180,30);
    box2 = createSprite(310,580,180,30);
    box3 = createSprite(510,580,180,30);
    box4 = createSprite(710,580,180,30);
    ball = createSprite(random(20,750),300,50,50);
    canvas = createCanvas(800,600);
    ball.velocityX = 10
    ball.velocityY = 10
    ball.shapeColor = "white"
   
    



    //create box sprite and give velocity

}

function draw() {
    background("black");
    drawSprites()
    box1.shapeColor = "yellow"
    box2.shapeColor = "blue"
    box3.shapeColor = "green"
    box4.shapeColor = "red"
    if (ball.isTouching(box1)){
    ball.shapeColor ="yellow"
    }
    if (ball.isTouching(box2)){
     ball.shapeColor ="blue"
    }
    if (ball.isTouching(box3)){
    ball.shapeColor ="green"
    }
    if (ball.isTouching(box4)){
    ball.shapeColor ="red"
    }

    ball.bounceOff(box1);
    ball.bounceOff(box2);
    ball.bounceOff(box3);
    ball.bounceOff(box4);
    edges = createEdgeSprites();
    ball.bounceOff(edges);

    //add condition to check if box touching surface and make it box
}
